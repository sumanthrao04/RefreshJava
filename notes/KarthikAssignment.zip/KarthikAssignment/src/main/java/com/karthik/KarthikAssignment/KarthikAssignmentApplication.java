package com.karthik.KarthikAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KarthikAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(KarthikAssignmentApplication.class, args);
	}

}
